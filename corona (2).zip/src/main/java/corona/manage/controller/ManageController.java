package corona.manage.controller;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import corona.common.common.CommandMap;
import corona.manage.dao.ManageDAO;
import corona.manage.service.ManageService;

@Controller
public class ManageController {
	Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="manageService")
	private ManageService manageService;
	
	@Resource(name="manageDAO")
	private ManageDAO manageDAO;
	
	
	/*Ȯ���� ����*/
	@RequestMapping(value="/manage/confirmManage.do")
    public ModelAndView confirmManage(CommandMap commandMap) throws Exception{
    	System.out.println("confirmManageŽ");
		ModelAndView mv = new ModelAndView("/manage/confirmManage");
    	
    	return mv;
    }
	
	@RequestMapping(value="/manage/selectConfirmList.do")
    public ModelAndView selectConfirmList(CommandMap commandMap) throws Exception{
		log.debug("selectConfirmList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = manageService.selectConfirmList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	@RequestMapping(value = "/manage/confirmManageExcelUp.do", method = RequestMethod.POST)
	public ModelAndView confirmManageExcelUp(MultipartFile testFile, MultipartHttpServletRequest request) throws Exception {
		System.out.println("confirmManageExcelUpŽ");
		MultipartFile excelFile = request.getFile("excelFile");
		String ins_id = request.getParameter("INS_ID");

		if (excelFile == null || excelFile.isEmpty()) {
			throw new RuntimeException("���������� ���� �� �ּ���.");
		}

		File destFile = new File("C:\\" + excelFile.getOriginalFilename());
		try {
			excelFile.transferTo(destFile);

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap = manageService.confirmManageExcelUp(destFile,ins_id);
		destFile.delete();

		ModelAndView mv = new ModelAndView("jsonView");
		
		mv.addObject("resultMap", resultMap);
		
		return mv;
	}
	
	//���û���
	@RequestMapping(value="/manage/deleteConfirmChk.do")
	@ResponseBody
	public Map<String, Object> allListDel(@RequestParam(value="val[]") List<Integer> vals) throws Exception{
		Map<String, Object> map = new HashMap<String,Object>();
		System.out.println("vals Ȯ�� : " + vals.toString());
		
	    for(int i=0; i<vals.size() ;i++){
	        //System.out.println("vals(" + i + ") : " + vals.get(i));
	        map.put("selId", vals.get(i));
	        manageDAO.updateDelConfirmAllList(map);
	    }
		
		return map;
	}
	
	
	/*�ڰ��ݸ���_���������� ����*/
	@RequestMapping(value="/manage/domesticContactManage.do")
    public ModelAndView domesticContactManage(CommandMap commandMap) throws Exception{
    	System.out.println("domesticContactManageŽ");
		ModelAndView mv = new ModelAndView("/manage/domesticContactManage");
    	
    	return mv;
    }
	
	
	@RequestMapping(value="/manage/selectDomesticContactList.do")
    public ModelAndView selectDomesticContactList(CommandMap commandMap) throws Exception{
		log.debug("selectDomesticContactList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = manageService.selectDomesticContactList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	@ResponseBody
	@RequestMapping(value = "/manage/domesticContactExcelUp.do", method = RequestMethod.POST)
	public ModelAndView domesticContactExcelUp(MultipartFile testFile, MultipartHttpServletRequest request,HttpServletResponse response) throws Exception {
		System.out.println("domesticContactExcelUpŽ");
		MultipartFile excelFile = request.getFile("excelFile");
		String ins_id = request.getParameter("INS_ID");
		
		if (excelFile == null || excelFile.isEmpty()) {
			throw new RuntimeException("���������� ���� �� �ּ���.");
		}

		File destFile = new File("C:\\" + excelFile.getOriginalFilename());
		try {
			excelFile.transferTo(destFile);

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap = manageService.domesticContactExcelUp(destFile,ins_id);

		destFile.delete();

		ModelAndView mv = new ModelAndView("jsonView");
		
		mv.addObject("resultMap", resultMap);
		
		return mv;
	}
	
	//���û���
	@RequestMapping(value="/manage/deleteDomesticChk.do")
	@ResponseBody
	public Map<String, Object> allDomesticListDel(@RequestParam(value="val[]") List<Integer> vals) throws Exception{
		Map<String, Object> map = new HashMap<String,Object>();
		System.out.println("vals Ȯ�� : " + vals.toString());
		
	    for(int i=0; i<vals.size() ;i++){
	        //System.out.println("vals(" + i + ") : " + vals.get(i));
	        map.put("selId", vals.get(i));
	        manageDAO.updateDelDomesticAllList(map);
	    }
		
		return map;
	}
	
	//���û���
	@RequestMapping(value="/manage/deleteOverseaChk.do")
	@ResponseBody
	public Map<String, Object> allOverseaListDel(@RequestParam(value="val[]") List<Integer> vals) throws Exception{
		Map<String, Object> map = new HashMap<String,Object>();
		System.out.println("vals Ȯ�� : " + vals.toString());
		
	    for(int i=0; i<vals.size() ;i++){
	        //System.out.println("vals(" + i + ") : " + vals.get(i));
	        map.put("selId", vals.get(i));
	        manageDAO.updateDelOverseaAllList(map);
	    }
		
		return map;
	}
	
	/*�ڰ��ݸ���_�ؿ��Ա��� ����*/
	@RequestMapping(value="/manage/overseaManage.do")
    public ModelAndView overseaManage(CommandMap commandMap) throws Exception{
    	System.out.println("overseaManageŽ");
		ModelAndView mv = new ModelAndView("/manage/overseaManage");
    	
    	return mv;
    }
	
	@RequestMapping(value="/manage/selectOverseaList.do")
    public ModelAndView selectOverseaList(CommandMap commandMap) throws Exception{
		log.debug("selectOverseaList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = manageService.selectOverseaList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	@ResponseBody
	@RequestMapping(value = "/manage/overseaExcelUp.do", method = RequestMethod.POST)
	public ModelAndView overseaExcelUp(MultipartFile testFile, MultipartHttpServletRequest request) throws Exception {
		System.out.println("overseaExcelUpŽ");
		MultipartFile excelFile = request.getFile("excelFile");
		String ins_id = request.getParameter("INS_ID");

		if (excelFile == null || excelFile.isEmpty()) {
			throw new RuntimeException("���������� ���� �� �ּ���.");
		}

		File destFile = new File("C:\\" + excelFile.getOriginalFilename());
		try {
			excelFile.transferTo(destFile);

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap = manageService.overseaExcelUp(destFile,ins_id);

		destFile.delete();

		ModelAndView mv = new ModelAndView("jsonView");
		
		mv.addObject("resultMap", resultMap);

		return mv;
	}
	
	/*���ο� ����*/
	@RequestMapping(value="/manage/consultManage.do")
    public ModelAndView consultManage(CommandMap commandMap) throws Exception{
    	System.out.println("consultManageŽ");
		ModelAndView mv = new ModelAndView("/manage/consultManage");
    	
    	return mv;
    }
	
	
	@RequestMapping(value="/manage/selectConsultList.do")
    public ModelAndView selectConsultList(CommandMap commandMap) throws Exception{
		log.debug("selectConsultList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = manageService.selectConsultList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	@ResponseBody
	@RequestMapping(value = "/manage/consultExcelUp.do", method = RequestMethod.POST)
	public ModelAndView consultExcelUp(MultipartFile testFile, MultipartHttpServletRequest request) throws Exception {
		System.out.println("consultExcelUpŽ");
		MultipartFile excelFile = request.getFile("excelFile");
		String ins_id = request.getParameter("INS_ID");

		if (excelFile == null || excelFile.isEmpty()) {
			throw new RuntimeException("���������� ���� �� �ּ���.");
		}

		File destFile = new File("C:\\" + excelFile.getOriginalFilename());
		try {
			excelFile.transferTo(destFile);

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap = manageService.consultExcelUp(destFile,ins_id);

		destFile.delete();

		ModelAndView mv = new ModelAndView("jsonView");
		
		mv.addObject("resultMap", resultMap);

		return mv;
	}
	
	/*��������� �˻� ����*/
	@RequestMapping(value="/manage/clinicManage.do")
    public ModelAndView clinicManage(CommandMap commandMap) throws Exception{
    	System.out.println("clinicManageŽ");
		ModelAndView mv = new ModelAndView("/manage/clinicManage");
    	
    	return mv;
    }
	
	@RequestMapping(value="/manage/selectClinicList.do")
    public ModelAndView selectClinicList(CommandMap commandMap) throws Exception{
		log.debug("selectClinicList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = manageService.selectClinicList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	@ResponseBody
	@RequestMapping(value = "/manage/clinicExcelUp.do", method = RequestMethod.POST)
	public ModelAndView clinicExcelUp(MultipartFile testFile, MultipartHttpServletRequest request) throws Exception {
		System.out.println("clinicExcelUpŽ");
		MultipartFile excelFile = request.getFile("excelFile");
		String ins_id = request.getParameter("INS_ID");

		if (excelFile == null || excelFile.isEmpty()) {
			throw new RuntimeException("���������� ���� �� �ּ���.");
		}

		File destFile = new File("C:\\" + excelFile.getOriginalFilename());
		try {
			excelFile.transferTo(destFile);

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap = manageService.clinicExcelUp(destFile,ins_id);

		destFile.delete();

		ModelAndView mv = new ModelAndView("jsonView");
		
		mv.addObject("resultMap", resultMap);

		return mv;
	}
	
	//���û���
	@RequestMapping(value="/manage/deleteClinicChk.do")
	@ResponseBody
	public Map<String, Object> allClinicListDel(@RequestParam(value="val[]") List<Integer> vals) throws Exception{
		Map<String, Object> map = new HashMap<String,Object>();
		System.out.println("vals Ȯ�� : " + vals.toString());
		
	    for(int i=0; i<vals.size() ;i++){
	        //System.out.println("vals(" + i + ") : " + vals.get(i));
	        map.put("selId", vals.get(i));
	        manageDAO.updateDelClinicAllList(map);
	    }
		
		return map;
	}
	

	
}
