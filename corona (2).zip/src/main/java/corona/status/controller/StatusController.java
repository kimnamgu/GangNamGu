package corona.status.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import corona.common.common.CommandMap;
import corona.status.service.StatusService;

@Controller
public class StatusController {
	Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="statusService")
	private StatusService statusService;
	
	@RequestMapping(value="/status/mainStatusView.do")
    public ModelAndView mainStatusView(CommandMap commandMap) throws Exception{
    	System.out.println("mainStatusViewŽ");
    	
    	
    	SimpleDateFormat format1 = new SimpleDateFormat ( "yyyyMMdd");
    	SimpleDateFormat format2 = new SimpleDateFormat ( "MM��dd��");
    			
    	Date time = new Date();
    			
    	String time1 = format1.format(time);
    	String time2 = format2.format(time);
    	
    	commandMap.put("seldate", time1);
    	commandMap.put("showdate", time2);
    	
		ModelAndView mv = new ModelAndView("/status/mainStatusView");
		
		
		/*�Ѱ����*/
		Map<String,Object> totalMap = statusService.selectTotalStatus(commandMap.getMap());
		mv.addObject("totalMap", totalMap.get("map"));
		
		/*Ȯ�������*/
		Map<String,Object> confirmMap = statusService.selectConfirmStatus(commandMap.getMap());
		Map<String,Object> confirmAccumMap = statusService.selectConfirmStatusAccum(commandMap.getMap());
		List<Map<String,Object>> confirmOverseaList = statusService.selectConfirmStatusOverseaList(commandMap.getMap());
    	
    	mv.addObject("confirmMap", confirmMap.get("map"));
    	mv.addObject("confirmAccumMap", confirmAccumMap.get("map"));
    	mv.addObject("confirmOverseaList", confirmOverseaList);
    	
		/*�ڰ��ݸ������*/
		Map<String,Object> domIsoMap = statusService.selectDomesticStatus(commandMap.getMap());
		Map<String,Object> overseaIsoMap = statusService.selectOverseaStatus(commandMap.getMap());
    	
    	mv.addObject("domIsoMap", domIsoMap.get("map"));
    	mv.addObject("overseaIsoMap", overseaIsoMap.get("map"));
    	
		/*���ο����*/
		Map<String,Object> consultMap = statusService.selectConsultStatus(commandMap.getMap());
		
		mv.addObject("consultMap", consultMap.get("map"));
				
		/*��������� ���*/
		Map<String,Object> clinicMap = statusService.selectClinicStatus(commandMap.getMap());
		
		mv.addObject("clinicMap", clinicMap.get("map"));
		
		/*��������� �˻����̽����*/
		Map<String,Object> clinicCaseMap = statusService.selectClinicCaseStatus(commandMap.getMap());
		
		mv.addObject("clinicCaseMap", clinicCaseMap.get("map"));
    	
    	
		
    	return mv;
    }
	
	@RequestMapping(value="/status/statusMiddleView.do")
	public ModelAndView statusMiddleView(CommandMap commandMap, HttpServletRequest request,ModelMap model) throws Exception{
		System.out.println("statusMiddleViewŽ");
		
		ModelAndView mv = new ModelAndView("/status/statusMiddleView");
		
		model.addAttribute("WRITE_DATE",commandMap.get("WRITE_DATE"));
		model.addAttribute("DEPART",commandMap.get("DEPART"));
		
		//�Ѱ�
		model.addAttribute("TOTALSUM",commandMap.get("TOTALSUM"));
		//�Ѱ� ���� �׷���
		if(commandMap.get("TOTALSUM") != null && commandMap.get("TOTALSUM").equals("Y")){
			List<Map<String,Object>> totalStatisticList = statusService.selectTotalStatisticsList(commandMap.getMap());
			model.addAttribute("totalStatisticList",totalStatisticList);
		}
		
		
		//Ȯ����
		model.addAttribute("INFECT_GUBUN",commandMap.get("INFECT_GUBUN"));
		model.addAttribute("INFECT_DAE",commandMap.get("INFECT_DAE"));
		model.addAttribute("INFECT_SO",commandMap.get("INFECT_SO"));
		
		//Ȯ���� ���� ���� ǥ��
		if(commandMap.get("INFECT_GUBUN") != null && commandMap.get("INFECT_GUBUN").equals("ALL")){
			List<Map<String,Object>> confirmMaplist = statusService.selectConfirmMaplist(commandMap.getMap());
			List<Map<String,Object>> confirmStatisticList = statusService.selectConfirmStatisticlist(commandMap.getMap());
			
			model.addAttribute("confirmMaplist",confirmMaplist);
			model.addAttribute("confirmStatisticList",confirmStatisticList);
		}
		
		//�ڰ��ݸ���
		model.addAttribute("ISO",commandMap.get("ISO"));
		model.addAttribute("WRITE_DATE",commandMap.get("WRITE_DATE"));
		
		//�ڰ��ݸ��� �׷���
		if(commandMap.get("ISO") != null && commandMap.get("ISO").equals("Y")){
			List<Map<String,Object>> isoMaplist = statusService.selectIsoMaplist(commandMap.getMap());
			model.addAttribute("isoMaplist",isoMaplist);
			
			List<Map<String,Object>> isoStatisticList = statusService.selectIsoStatisticsList(commandMap.getMap());
			model.addAttribute("isoStatisticList",isoStatisticList);
		}
		
		//���ο�
		model.addAttribute("CONSULTSUM",commandMap.get("CONSULTSUM"));
		
		//���ο� �׷���
		if(commandMap.get("CONSULTSUM") != null && commandMap.get("CONSULTSUM").equals("Y")){
			List<Map<String,Object>> consultStatisticList = statusService.selectConsultStatisticsList(commandMap.getMap());
			model.addAttribute("consultStatisticList",consultStatisticList);
		}
		
/*		//���ο�
		model.addAttribute("CLINICSUM",commandMap.get("CLINICSUM"));
		
		//���������
		model.addAttribute("CLINIC_GUBUN",commandMap.get("CLINIC_GUBUN"));
		model.addAttribute("CLINIC_OVERDOMGUBUN",commandMap.get("CLINIC_OVERDOMGUBUN"));
		model.addAttribute("CLINIC_CONDITION",commandMap.get("CLINIC_CONDITION"));
		model.addAttribute("CLINIC_SELDATE",commandMap.get("CLINIC_SELDATE"));*/
		
		//��������� ���̽�
		model.addAttribute("CLINIC_CASE_GUBUN",commandMap.get("CLINIC_CASE_GUBUN"));
		model.addAttribute("CLINIC_CASE_CONDITION",commandMap.get("CLINIC_CASE_CONDITION"));
		model.addAttribute("CLINIC_CASE_SELDATE",commandMap.get("CLINIC_CASE_SELDATE"));
		return mv;
	}
	
	/*�������� �߰�*/
	@RequestMapping(value="/status/selectConsultMiddle.do")
    public ModelAndView selectConsultMiddle(CommandMap commandMap) throws Exception{
		log.debug("selectConsultMiddle param2= [" + commandMap.getMap().toString() + "]");
		System.out.println("commandMap Ȯ�� : " + commandMap.getMap().toString());
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = statusService.selectConsultMiddle(commandMap.getMap());
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	/*�ڰ��ݸ��߰����-�ؿ�*/
	@RequestMapping(value="/status/selectIsoOverseaMiddle.do")
    public ModelAndView selectIsoOverseaMiddle(CommandMap commandMap) throws Exception{
		log.debug("selectIsoOverseaMiddle param2= [" + commandMap.getMap().toString() + "]");
		System.out.println("commandMap Ȯ�� : " + commandMap.getMap().toString());
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = statusService.selectIsoOverseaMiddle(commandMap.getMap());
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	/*�ڰ��ݸ��߰����-����*/
	@RequestMapping(value="/status/selectIsoDomMiddle.do")
    public ModelAndView selectIsoDomMiddle(CommandMap commandMap) throws Exception{
		log.debug("selectIsoDomMiddle param2= [" + commandMap.getMap().toString() + "]");
		System.out.println("commandMap Ȯ�� : " + commandMap.getMap().toString());
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = statusService.selectIsoDomMiddle(commandMap.getMap());
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	/*�ڰ��ݸ��߰����-�ؿ�*/
	@RequestMapping(value="/status/selectIsoOverseaAccumMiddle.do")
    public ModelAndView selectIsoOverseaAccumMiddle(CommandMap commandMap) throws Exception{
		log.debug("selectIsoDomAccumMiddle param2= [" + commandMap.getMap().toString() + "]");
		System.out.println("commandMap Ȯ�� : " + commandMap.getMap().toString());
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = statusService.selectIsoOverseaAccumMiddle(commandMap.getMap());
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	/*�ڰ��ݸ��߰����-����*/
	@RequestMapping(value="/status/selectIsoDomAccumMiddle.do")
    public ModelAndView selectIsoDomAccumMiddle(CommandMap commandMap) throws Exception{
		log.debug("selectIsoDomAccumMiddle param2= [" + commandMap.getMap().toString() + "]");
		System.out.println("commandMap Ȯ�� : " + commandMap.getMap().toString());
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = statusService.selectIsoDomAccumMiddle(commandMap.getMap());
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	
	/*�Ѱ��߰����*/
	@RequestMapping(value="/status/selectTotalMiddle.do")
    public ModelAndView selectTotalMiddle(CommandMap commandMap) throws Exception{
		log.debug("selectTotalMiddle param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = statusService.selectTotalMiddle(commandMap.getMap());
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	/*�Ѱ��߰����-Ÿ��*/
	@RequestMapping(value="/status/selectTotalExMiddle.do")
    public ModelAndView selectTotalExMiddle(CommandMap commandMap) throws Exception{
		log.debug("selectTotalExMiddle param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = statusService.selectTotalExMiddle(commandMap.getMap());
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	
	/*�Ѱ��߰����-�ؿ�*/
	@RequestMapping(value="/status/selectTotalExOverseaMiddle.do")
    public ModelAndView selectTotalExOverseaMiddle(CommandMap commandMap) throws Exception{
		log.debug("selectTotalExOverseaMiddle param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = statusService.selectTotalExOverseaMiddle(commandMap.getMap());
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	
	
	
	@RequestMapping(value="/status/statusAccumMiddleView.do")
	public ModelAndView statusAccumMiddleView(CommandMap commandMap, HttpServletRequest request,ModelMap model) throws Exception{
		System.out.println("statusAccumMiddleViewŽ");
		
		ModelAndView mv = new ModelAndView("/status/statusAccumMiddleView");
		
		model.addAttribute("WRITE_DATE",commandMap.get("WRITE_DATE"));
		
		//Ȯ����
		model.addAttribute("INFECT_GUBUN",commandMap.get("INFECT_GUBUN"));
		model.addAttribute("INFECT_DAE",commandMap.get("INFECT_DAE"));
		model.addAttribute("INFECT_SO",commandMap.get("INFECT_SO"));
		
		return mv;
	}
	
	/*Ȯ���� �߰� ���- �ؿ�*/
	@RequestMapping(value="/status/selectConfirmMiddleOversea.do")
    public ModelAndView selectConfirmMiddleOversea(CommandMap commandMap) throws Exception{
		log.debug("selectConfirmMiddleOversea param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
    	
		if(!commandMap.get("DEPART").equals("accum")){
		   	list = statusService.selectConfirmMiddleOversea(commandMap.getMap());
		}else{
			list = statusService.selectConfirmAccumMiddleOversea(commandMap.getMap());
		}
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	/*Ȯ���� �߰���� - ����*/
	@RequestMapping(value="/status/selectConfirmMiddleHospital.do")
    public ModelAndView selectConfirmMiddleHospital(CommandMap commandMap) throws Exception{
		log.debug("selectConfirmMiddleHospital param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		if(!commandMap.get("DEPART").equals("accum")){
			list = statusService.selectConfirmMiddleHospital(commandMap.getMap());
		}else{
			list = statusService.selectConfirmAccumMiddleHospital(commandMap.getMap());
		}
		
    	mv.addObject("list", list);
    	mv.addObject("list_size", list.size());

    	return mv;
    }
	
	
	
	@RequestMapping(value="/status/statusTrackingView.do")
	public ModelAndView statusTrackingVeiw(CommandMap commandMap, HttpServletRequest request,ModelMap model) throws Exception{
		System.out.println("statusTrackingVeiwŽ");
		System.out.println("commandMap Ȯ�� : " + commandMap.getMap()); 
		
		ModelAndView mv = new ModelAndView("/status/statusTrackingView");
		
		model.addAttribute("WRITE_DATE",commandMap.get("WRITE_DATE"));
		model.addAttribute("ETC_GUBUN",commandMap.get("ETC_GUBUN"));
		model.addAttribute("ETC_GUBUN_CONDITION",commandMap.get("ETC_GUBUN_CONDITION"));
		
		//Ȯ����
		model.addAttribute("TOTAL_GUBUN",commandMap.get("TOTAL_GUBUN"));
		model.addAttribute("TOTAL_CONDITION",commandMap.get("TOTAL_CONDITION"));
		model.addAttribute("TOTAL_DONG_GUBUN",commandMap.get("TOTAL_DONG_GUBUN"));
		
		//Ȯ����
		model.addAttribute("INFECT_GUBUN",commandMap.get("INFECT_GUBUN"));
		model.addAttribute("INFECT_DAE",commandMap.get("INFECT_DAE"));
		model.addAttribute("INFECT_SO",commandMap.get("INFECT_SO"));
		
		//�ڰ��ݸ���
		model.addAttribute("ISO_GUBUN",commandMap.get("ISO_GUBUN"));
		model.addAttribute("ISO_CONDITION",commandMap.get("ISO_CONDITION"));
		model.addAttribute("ISO_CONDITION2",commandMap.get("ISO_CONDITION2"));
		model.addAttribute("ISO_CONDITION3",commandMap.get("ISO_CONDITION3"));
		
		model.addAttribute("ISO_ALL_GUBUN",commandMap.get("ISO_ALL_GUBUN"));
		
		//���ο�
		model.addAttribute("CONSULT_DEPART",commandMap.get("CONSULT_DEPART"));
		model.addAttribute("CONSULT_JUYA_GUBUN",commandMap.get("CONSULT_JUYA_GUBUN"));
		model.addAttribute("CONSULT_CONSULT_GUBUN",commandMap.get("CONSULT_CONSULT_GUBUN"));
		
		//���������
		model.addAttribute("CLINIC_DEPART",commandMap.get("CLINIC_DEPART"));
		model.addAttribute("CLINIC_SUSPICION_GUBUN",commandMap.get("CLINIC_SUSPICION_GUBUN"));
		model.addAttribute("CLINIC_SUSPICION_DAE",commandMap.get("CLINIC_SUSPICION_DAE"));
		model.addAttribute("CLINIC_SUSPICION_SO",commandMap.get("CLINIC_SUSPICION_SO"));
		model.addAttribute("ISO",commandMap.get("ISO"));
		
		//��������� �缺��
		model.addAttribute("CLINIC_CONFIRM_DEPART",commandMap.get("CLINIC_CONFIRM_DEPART"));
		model.addAttribute("CLINIC_CONFIRM_SUSPICION_GUBUN",commandMap.get("CLINIC_CONFIRM_SUSPICION_GUBUN"));
		model.addAttribute("CLINIC_CONFIRM_SUSPICION_DAE",commandMap.get("CLINIC_CONFIRM_SUSPICION_DAE"));
		model.addAttribute("CLINIC_CONFIRM_SUSPICION_SO",commandMap.get("CLINIC_CONFIRM_SUSPICION_SO"));
		model.addAttribute("CONFIRM_ISO",commandMap.get("CONFIRM_ISO"));
		
		//��������� ���̽�
		model.addAttribute("CLINIC_CASE_GUBUN",commandMap.get("CLINIC_CASE_GUBUN"));
		model.addAttribute("CLINIC_CASE_CONDITION",commandMap.get("CLINIC_CASE_CONDITION"));
		model.addAttribute("CLINIC_CASE_SELDATE",commandMap.get("CLINIC_CASE_SELDATE"));
		
		return mv;
	}
	
	@RequestMapping(value="/status/selectTotalDtlList.do")
    public ModelAndView selectTotalDtlList(CommandMap commandMap) throws Exception{
		log.debug("selectTotalDtlList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = statusService.selectTotalDtlList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	
	@RequestMapping(value="/status/selectConfirmDtlList.do")
    public ModelAndView selectConfirmDtlList(CommandMap commandMap) throws Exception{
		log.debug("selectConfirmDtlList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = statusService.selectConfirmDtlList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	/*�ڰ��ݸ��� �ؿ��Ա���*/
	@RequestMapping(value="/status/selectIsoOverseaDtlList.do")
    public ModelAndView selectOverseaDtlList(CommandMap commandMap) throws Exception{
		log.debug("selectIsoOverseaDtlList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = statusService.selectIsoOverseaDtlList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	/*�ڰ��ݸ��� ����������*/
	@RequestMapping(value="/status/selectIsoDomesticDtlList.do")
    public ModelAndView selectDomesticDtlList(CommandMap commandMap) throws Exception{
		log.debug("selectDomesticDtlList param2= [" + commandMap.getMap().toString() + "]");
		System.out.println("CommandMap Ȯ�� : " +commandMap.getMap().toString());
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = statusService.selectIsoDomesticDtlList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	/*���ο�*/
	@RequestMapping(value="/status/selectConsultDtlList.do")
    public ModelAndView selectConsultDtlList(CommandMap commandMap) throws Exception{
		System.out.println("selectConsultDtlList");
		log.debug("selectConsultDtlList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = statusService.selectConsultDtlList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	/*���������*/
	@RequestMapping(value="/status/selectClinicDtlList.do")
    public ModelAndView selectClinicDtlList(CommandMap commandMap) throws Exception{
		System.out.println("selectClinicDtlList");
		log.debug("selectClinicDtlList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = statusService.selectClinicDtlList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	/*��������� �缺��*/
	@RequestMapping(value="/status/selectClinicConfirmDtlList.do")
    public ModelAndView selectClinicConfirmDtlList(CommandMap commandMap) throws Exception{
		System.out.println("selectClinicConfirmDtlList");
		log.debug("selectClinicConfirmDtlList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = statusService.selectClinicConfirmDtlList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	/*���������*/
	@RequestMapping(value="/status/selectClinicCaseDtlList.do")
    public ModelAndView selectClinicCaseDtlList(CommandMap commandMap) throws Exception{
		System.out.println("selectClinicDtlList");
		log.debug("selectClinicCaseDtlList param2= [" + commandMap.getMap().toString() + "]");
		
		ModelAndView mv = new ModelAndView("jsonView");
    	
    	List<Map<String,Object>> list = statusService.selectClinicCaseDtlList(commandMap.getMap());
    	
    	mv.addObject("list", list);
    	
    	if(list.size() > 0){
    		mv.addObject("total", list.get(0).get("TOTAL_COUNT"));
    	}
    	else{
    		mv.addObject("total", 0);
    	}
    	
    	return mv;
    }
	
	
	@RequestMapping(value="/status/statusMiddleClinicView.do")
	public ModelAndView statusMiddleClinicView(CommandMap commandMap, HttpServletRequest request,ModelMap model) throws Exception{
		System.out.println("statusMiddleClinicViewŽ");
		System.out.println("commandMap Ȯ�� : " + commandMap.getMap().toString());
		
		ModelAndView mv = new ModelAndView("/status/statusMiddleClinicView");
		
		model.addAttribute("SELDATE",commandMap.get("SELDATE"));
		
		String SHOWDATE = ((String) commandMap.get("SELDATE"));
		
		model.addAttribute("SHOWDATE",SHOWDATE.substring(0,4) + "-" + SHOWDATE.substring(4,6) + "-" + SHOWDATE.substring(6,8));
		
		
		//�ڰ��ݸ��� �׷���
		List<Map<String,Object>> clinicStatisticList = statusService.selectClinicStatisticsList(commandMap.getMap());
		model.addAttribute("clinicStatisticList",clinicStatisticList);
		
		
		//�հ� ����
		Map<String,Object> sumMap = statusService.selectClinicMiddleSumStatus(commandMap.getMap());
		mv.addObject("sumMap", sumMap.get("map"));
		
		
		//���� �ڰ��ݸ��� ����
		commandMap.put("ISO","ISO_EX");
		
		List<Map<String,Object>> selectClinicGangnamMiddleList = statusService.selectClinicGangnamMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicGangnamMiddleList", selectClinicGangnamMiddleList);
		
		List<Map<String,Object>> selectClinicTasiguMiddleList = statusService.selectClinicTasiguMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicTasiguMiddleList", selectClinicTasiguMiddleList);
		
		List<Map<String,Object>> selectClinicOverseaMiddleList = statusService.selectClinicOverseaMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicOverseaMiddleList", selectClinicOverseaMiddleList);
    	
    	//���� �ڰ��ݸ���
		commandMap.put("ISO","ISO");
		
		List<Map<String,Object>> selectClinicGangnamIsoMiddleList = statusService.selectClinicGangnamMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicGangnamIsoMiddleList", selectClinicGangnamIsoMiddleList);
		
		List<Map<String,Object>> selectClinicTasiguIsoMiddleList = statusService.selectClinicTasiguMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicTasiguIsoMiddleList", selectClinicTasiguIsoMiddleList);
    	
		List<Map<String,Object>> selectClinicOverseaIsoMiddleList = statusService.selectClinicOverseaMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicOverseaIsoMiddleList", selectClinicOverseaIsoMiddleList);
		
    	//����
		commandMap.put("ISO","");
		commandMap.put("SELDATE","");
		
		List<Map<String,Object>> selectClinicGangnamAccumMiddleList = statusService.selectClinicGangnamMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicGangnamAccumMiddleList", selectClinicGangnamAccumMiddleList);
		
		List<Map<String,Object>> selectClinicTasiguAccumMiddleList = statusService.selectClinicTasiguMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicTasiguAccumMiddleList", selectClinicTasiguAccumMiddleList);
		
		List<Map<String,Object>> selectClinicOverseaAccumMiddleList = statusService.selectClinicOverseaMiddleList(commandMap.getMap());
    	mv.addObject("selectClinicOverseaAccumMiddleList", selectClinicOverseaAccumMiddleList);
		
		return mv;
	}
}
