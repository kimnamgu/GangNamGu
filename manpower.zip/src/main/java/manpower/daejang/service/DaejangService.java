package manpower.daejang.service;

public interface DaejangService {


}
