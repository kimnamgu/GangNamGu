package manpower.daejang.dao;

import org.springframework.stereotype.Repository;

import manpower.common.dao.AbstractDAO;

@Repository("daejangDAO")
public class DaejangDAO extends AbstractDAO{

	
}
